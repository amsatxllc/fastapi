"""Main entry point for the app.

This app is generated based on your prompt in Vertex AI Studio using
Google GenAI Python SDK (https://googleapis.github.io/python-genai/) and
Gradio (https://www.gradio.app/).

You can customize the app by editing the code in Cloud Run source code editor.
You can also update the prompt in Vertex AI Studio and redeploy it.
"""

import base64
from google import genai
from google.genai import types
import gradio as gr
import utils


def generate(
    message,
    history: list[gr.ChatMessage],
    request: gr.Request
):
  """Function to call the model based on the request."""

  validate_key_result = utils.validate_key(request)
  if validate_key_result is not None:
    yield validate_key_result
    return

  client = genai.Client(
      vertexai=True,
      project="theforgeai-c4d2d",
      location="us-central1",
  )
  msg1_text1 = types.Part.from_text(text=f"""\"Your task is to create a Python application that will run on Google Cloud (e.g., Cloud Run) and serve as the API layer for the AI trading 'brain'. This application will implement the agentic API contract to communicate with the trading bots. It should be built using a modern asynchronous Python web framework like FastAPI.
Core Requirements:
Framework: Use FastAPI for building the API endpoints.
Hosting Target: Design for deployment on Cloud Run (implying a stateless application container).
API Endpoints: Implement the following POST endpoints:
/api/v1/bot/get_directives:
Accepts JSON payload: {{\"bot_id\": str, \"last_directive_id_received\": Optional[str], \"timestamp\": str}}.
Requires API key authentication (check X-AI-Bot-API-Key header against a secret configured in Cloud Run). Return 401 Unauthorized if invalid.
Internal Logic Placeholder: Implement placeholder logic that simulates fetching directives for the given bot_id generated since last_directive_id_received. In a real implementation, this would query a directive storage (e.g., Firestore) populated by the core Strategy Engine. For this version, return a hardcoded list of mock directives for testing, or query a simple in-memory/file-based store for demonstration.
Return JSON payload: {{\"timestamp_generated\": str, \"directives\": List[Dict[str, Any]]}}.
/api/v1/bot/report_state:
Accepts JSON payload: {{\"bot_id\": str, \"timestamp\": str, \"account_state\": Dict, \"open_positions\": List, \"open_orders\": List, \"closed_trades_since_last_report\": List}}.
Requires API key authentication.
Internal Logic Placeholder: Implement placeholder logic to simulate processing and storing this state information. In a real implementation, this would save the state to storage (e.g., Firestore/Cloud SQL) and potentially trigger analysis in the Strategy Engine. For this version, just log the received state and return a success message.
Return JSON payload: {{\"status\": \"received\", \"message\": str}}.
/api/v1/bot/confirm_directive:
Accepts JSON payload: {{\"bot_id\": str, \"directive_id\": str, \"timestamp\": str, \"execution_status\": str, \"details\": Optional[str], \"error_message\": Optional[str]}}.
Requires API key authentication.
Internal Logic Placeholder: Implement placeholder logic to simulate logging and processing this confirmation. In a real implementation, this would update the status of the directive in storage, log the outcome, and feed data to the adaptive learning component. For this version, just log the confirmation details and return a success message.
Return JSON payload: {{\"status\": \"acknowledged\"}}.
Authentication: Implement a simple API key check using a header for all endpoints. The key should be loaded from environment variables (suitable for Cloud Run secrets).
Logging: Use Python's logging module. Log incoming requests and the data received (be mindful of sensitive data). Log internal processing steps and simulated actions.
Dependencies: List necessary Python libraries (fastapi, uvicorn[standard], aiohttp - if needed for internal calls, pydantic - for data modeling, python-dotenv - for local testing).
Deployment Considerations: Include comments on how this application would be containerized (Dockerfile) and deployed to Cloud Run, mentioning secrets management for the API key.
Integration Note: Clearly state that this API layer interfaces with the actual trading intelligence (prediction models, strategy logic, risk engine) which would be implemented as separate modules or services, potentially leveraging Vertex AI Endpoints, and accessed internally by this API application. The placeholders should represent these internal interactions.""")


  model = "gemini-2.5-pro-preview-05-06"
  contents = [
    types.Content(
      role="user",
      parts=[
        msg1_text1
      ]
    ),
  ]

  for prev_msg in history:
    role = "user" if prev_msg["role"] == "user" else "model"
    parts = utils.get_parts_from_message(prev_msg["content"])
    if parts:
      contents.append(types.Content(role=role, parts=parts))

  if message:
    contents.append(
        types.Content(role="user", parts=utils.get_parts_from_message(message))
    )

  generate_content_config = types.GenerateContentConfig(
      temperature=1,
      top_p=1,
      seed=0,
      max_output_tokens=65535,
      safety_settings=[
          types.SafetySetting(
              category="HARM_CATEGORY_HATE_SPEECH",
              threshold="OFF"
          ),
          types.SafetySetting(
              category="HARM_CATEGORY_DANGEROUS_CONTENT",
              threshold="OFF"
          ),
          types.SafetySetting(
              category="HARM_CATEGORY_SEXUALLY_EXPLICIT",
              threshold="OFF"
          ),
          types.SafetySetting(
              category="HARM_CATEGORY_HARASSMENT",
              threshold="OFF"
          )
      ],
  )

  results = []
  for chunk in client.models.generate_content_stream(
      model=model,
      contents=contents,
      config=generate_content_config,
  ):
    if chunk.candidates and chunk.candidates[0] and chunk.candidates[0].content:
      results.extend(
          utils.convert_content_to_gr_type(chunk.candidates[0].content)
      )
      if results:
        yield results

with gr.Blocks(theme=utils.custom_theme) as demo:
  with gr.Row():
    gr.HTML(utils.public_access_warning)
  with gr.Row():
    with gr.Column(scale=1):
      with gr.Row():
        gr.HTML("<h2>Welcome to Vertex AI GenAI App!</h2>")
      with gr.Row():
        gr.HTML("""This prototype was built using your Vertex AI Studio prompt.
            Follow the steps and recommendations below to begin.""")
      with gr.Row():
        gr.HTML(utils.next_steps_html)

    with gr.Column(scale=2, variant="panel"):
      gr.ChatInterface(
          fn=generate,
          title="AI Trading Brain API with FastAPI",
          type="messages",
          multimodal=True,
      )
  demo.launch(show_error=True)